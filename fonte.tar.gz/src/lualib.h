/*
** $Id: lualib.h,v 1.45.1.1 2017/04/19 17:20:42 roberto Exp $
** Lua standard libraries
** See Copyright Notice in lua.h
*/


#ifndef lualib_h
#define lualib_h

#include "lua.h"


/* version suffix for environment variable names */
#define LUA_VERSUFFIX          "_" LUA_VERSION_MAJOR "_" LUA_VERSION_MINOR


LUAMOD_API int (luaopen_base) (lua_State *L);

#define LUA_COLIBNAME	"corrotina"
LUAMOD_API int (luaopen_coroutine) (lua_State *L);

#define LUA_TABLIBNAME	"tabela"
LUAMOD_API int (luaopen_table) (lua_State *L);

#define LUA_IOLIBNAME	"es"
LUAMOD_API int (luaopen_io) (lua_State *L);

#define LUA_OSLIBNAME	"so"
LUAMOD_API int (luaopen_os) (lua_State *L);

#define LUA_STRLIBNAME	"colar"
LUAMOD_API int (luaopen_string) (lua_State *L);

#define LUA_UTF8LIBNAME	"utf8"
LUAMOD_API int (luaopen_utf8) (lua_State *L);

#define LUA_MATHLIBNAME	"mat"
LUAMOD_API int (luaopen_math) (lua_State *L);

#define LUA_DBLIBNAME	"depure"
LUAMOD_API int (luaopen_debug) (lua_State *L);

#define LUA_LOADLIBNAME	"módulo"
LUAMOD_API int (luaopen_package) (lua_State *L);

/* JSON incorporado ao núcleo Santafé. */
#define LUA_JSONLIBNAME	"json"
LUAMOD_API int (luaopen_cjson) (lua_State *L);

/* open all previous libraries */
LUALIB_API void (luaL_openlibs) (lua_State *L);



#if !defined(lua_assert)
#define lua_assert(x)	((void)0)
#endif


#endif
