# Contrato experimental de dados da Santafé

O candidato `dados.10` define a IBA 3 e prepara a migração operacional sobre a base selada dados.9, sem alterar o contrato de delimitadores, mantendo listas nativas, nulo armazenável, ONFÉ e SLS, sem substituir a Santafé 2.1.0. É um laboratório de mudança incompatível, não uma versão pronta para instalação. Os fontes estáveis continuam compilando sem `SANTAFE_DADOS_EXPERIMENTAL`.

## Decisões consolidadas

- `{}` continua sendo **tabela**, com chaves textuais, numéricas e demais chaves admitidas pelo núcleo. Uma tabela esparsa não vira lista.
- `[]` constrói **lista**, indexada a partir de 1. Listas podem conter outras listas, tabelas e nulos.
- `nulo` é um valor armazenável. Atribuir `t.campo = nulo` conserva a associação; não a apaga.
- Não há novos valores públicos `inexistente`, `indefinido` ou `removido`. Ausência é uma condição consultável, não um valor de domínio adicional.
- Um acento grave delimita gabaritos com `®` e `Ⓡ`; `[=[...]=]`, `[==[...]==]` e níveis superiores delimitam colares brutos. Mantêm-se colares entre aspas e comentários `--`, `--[[...]]` e suas variantes com `=`. Funções continuam usando `função ... fim`; não se introduz `=>`.
- `.onfé` contém dados, não um programa. Sua leitura não executa funções, importações, interpolação ou expressões.

```santafé
local pessoa = { nome = "José", telefone = nulo }
local pedidos = [pessoa, nulo, { número = 42 }]
local bruto = [=[®nome permanece literal; \n também]=]
local nome = "José"
mostre(`Olá, ®nome! Quantidade: Ⓡ{#pedidos}`)
```

## Presença e exclusão

Os nomes de API para homologação são `tabela.temChave(t, chave)` e `tabela.apague(t, chave)`.

| Operação | Resultado |
| --- | --- |
| `t.a = nulo` | Cria ou conserva a chave `a` com valor nulo |
| `t.a` e `t.ausente` | Podem ambos retornar nulo |
| `tabela.temChave(t, "a")` | Consulta a associação própria, sem `__índice` |
| `tabela.apague(t, "a")` | Apaga explicitamente; retorna se existia |
| `pares(t)` | Inclui associações cujo valor é nulo |

`local x` continua inicializando `x` com nulo. Não se introduz exclusão de variável lexical nem erro novo por leitura de global ausente. Nulo permanece falso em condições e compara como nulo independentemente de sua representação interna.

`__índice` só atende ausência: nulo presente impede a busca herdada. `__novoÍndice` só intercepta associação ausente. Um metamétodo com valor nulo permanece desativado. A operação explícita de apagar não simula uma atribuição e não chama esses metamétodos.

## Listas e limites

O comprimento lógico inclui posições nulas e é obtido em tempo constante por `#lista` e `tamanho(lista)`. `ipares` percorre todas as posições, inclusive nulas. Tabelas conservam a regra de fronteira de sequência de `#`, não contagem de chaves; colares conservam a distinção entre grafemas e octetos.

O candidato adota estas regras operacionais para homologação:

- Atualizar `1..n` conserva o comprimento; escrever em `n+1` acrescenta uma posição.
- Escrever além de `n+1` dá erro antes de modificar a lista: não preenche buracos nem aloca pelo maior índice arbitrário.
- Ler um inteiro positivo além de `n` retorna nulo; `temChave` retorna falso.
- Índices textuais, negativos, zero, não finitos ou fracionários são recusados. `1.0` é numericamente o índice 1, mas `"1"` não é.
- `tabela.insira` insere; `tabela.remova` remove e devolve o elemento. `tabela.apague(lista, i)` remove e devolve um lógico. Remoções compactam as posições seguintes.
- Atribuir nulo a uma posição não compacta a lista.
- Listas do candidato não aceitam metatabelas. A extensão futura dessa capacidade precisa preservar os invariantes acima.

No candidato, o armazenamento de lista reutiliza o arranjo interno de tabela com marca e comprimento próprios, não uma tabela distinguida por heurística JSON. `tipo` distingue os dois; a IBA 3 ainda os representa como `LUA_TTABLE`, oferecendo `lua_islist` e `lua_createlist`. O carregador dinâmico exige o descritor `SANTAFE_MODULE_ABI` dos módulos recompilados. Não aceita bibliotecas instaladas de outra IBA. O contrato e os limites estão em `experimentos/dados-v10/IBA.md`.

## Colares brutos e migração léxica

Decisão reafirmada em 24/10/2026: manter o contrato dados.8. Não restaurar
`[[...]]` como colar nem exigir espaços entre aberturas de listas aninhadas.
`[[1,2],[3,4]]` e `[ [1,2], [3,4] ]` representam a mesma lista de listas.
Os delimitadores brutos com `=` preservam essa sintaxe herdada do Lua;
isso não significa compatibilidade com os antigos colares `[[...]]`, que
continuam exigindo a migração descrita abaixo.

Colares brutos exigem pelo menos um `=` na abertura: `[=[` fecha com `]=]`, `[==[` fecha com `]==]`, e assim por diante. Somente um fechamento com exatamente a mesma quantidade de `=` encerra o colar. O conteúdo não é aninhado. Para incluir um fechamento, escolha outro nível; acentos graves isolados ou duplos dentro do bruto são texto literal. `[=[]=]` é um bruto vazio.

Não há escapes nem interpolação em colares brutos. As quebras CRLF e CR são normalizadas para LF pelo lexer. Uma quebra imediatamente após a abertura é descartada, preservando a semântica dos colares longos estáveis. Para guardar uma quebra inicial, escreva duas. A migração a partir de dados.7 acrescenta essa quebra de proteção quando necessário.

`[[...]]` deixa de ser colar: `[[1,2],[3,4]]` é uma lista de listas. `[=[...]=]` e níveis maiores conservam sua semântica estável. Comentários longos não mudam. O migrador estável usa os lexemas do núcleo **estável**, converte somente os antigos colares `[[...]]` e conserva os níveis já válidos com `=`. O migrador de dados.7 usa o lexer daquele candidato para converter somente colares brutos com dois acentos graves. Nenhum migrador executa o programa recebido ou modifica o arquivo de entrada. Comentários e colares entre aspas não são transformados por busca textual.

Dois acentos graves consecutivos voltam a representar um gabarito vazio; não são delimitadores de bruto. ONFÉ não admite gabaritos, nem vazios. Construções antigas como `[[1]]` são ambíguas: podem compilar no candidato com outro significado. Por isso, nunca se deve testar compatibilidade apenas verificando se o código compila.

## ONFÉ

Exemplo de arquivo:

```santafé
{
    pessoa = { nome = "José", telefone = nulo },
    lista = [1, 2, nulo, 4],
    vazia = [],
    tabelaVazia = {},
    mapa = { [1] = "um", ["1"] = "chave textual" },
}
```

O parser admite raiz escalar ou composta, vírgula final, comentários, identificadores Unicode e chaves literais textuais, numéricas ou lógicas entre colchetes. Rejeita chaves duplicadas, código, gabaritos, ciclos na serialização, objetos com metatabela, números não finitos e tipos executáveis/opacos. A raiz e os valores podem ser nulos; chaves não podem.

Limites do candidato: entrada/saída de até 4 MiB, profundidade até 64 e até 200 mil lexemas, sujeitos também ao limite interno do lexer. O parser não usa `carregue` nem `executeArquivo` sobre o conteúdo. O módulo experimental é carregado pelo programa de teste, não pelo arquivo de dados.

API experimental: `onfé.decod`, `onfé.cod`, `onfé.carregue`, `onfé.paraJSON`, `onfé.deJSON`, `onfé.grave` e `onfé.graveAssíncrono`. A persistência atômica candidata e seus limites estão documentados em `experimentos/dados-v7/PERSISTENCIA.md`. O codificador pode emitir colares entre aspas: preserva o valor, não a formatação original dos delimitadores.

## Ponte JSON e decisões reservadas

JSON comum representa listas como arrays, tabelas de chaves textuais como objetos e nulo como `null`. `[]`, `{}` e associações nulas sobrevivem à ida e volta. O candidato recusa chaves numéricas/lógicas de tabelas ao gerar JSON comum, em vez de produzir silenciosamente nomes duplicados. A leitura JSON também recusa nomes duplicados.

A proposta anterior de converter automaticamente chaves textuais formadas por números **não está aplicada**: `"1"` e `1` permanecem distintos no candidato, preservando os dados existentes. Essa política exige homologação explícita antes de uma migração destrutiva; nomes com zeros iniciais e inteiros grandes agravam a ambiguidade.

ONFÉ conserva chaves numéricas sem restrição artificial imposta pelo JSON. O transporte JSON etiquetado, versionado e sem colisões com campos comuns foi projetado, mas não faz parte deste primeiro executável: a ponte atualmente oferecida é apenas JSON comum, com recusa explícita quando não puder representar as chaves. Inteiros de 64 bits são emitidos e lidos sem passar por `double` neste núcleo; consumidores JavaScript ainda precisam cuidar de inteiros maiores que sua faixa exata.

A forma `{var}` continua com a semântica anterior neste candidato. Não foi reinterpretada silenciosamente como `{var=nulo}`. A migração de construtores posicionais para `[]` precisa de análise de intenção; tabelas numéricas legítimas continuam existindo.

## Componentes e critérios para promoção

1. Núcleo: literal lista, colar bruto, presença/nulo, exclusão, GC, APIs brutas, metamétodos e assinatura de bytecode separada.
2. ONFÉ e JSON: parser de dados, limites, ida e volta, colisões de chaves e precisão.
3. SLS: no candidato `dados.2`, o serviço completo roda sobre o núcleo experimental, com exclusão explícita dos caches e listas JSON identificadas nas fronteiras do protocolo. ONFÉ recebe diagnóstico de dados, sem executar seu conteúdo; operações de código ficam indisponíveis em ONFÉ. Nomes sem declaração local visível podem gerar aviso opcional de escopo; não há `temVar` nem novo erro para globais dinâmicos.
4. Editores: kits experimentais separados para VS Code e Sublime, sem substituir as extensões publicadas nem a associação global de `.fé`. `dados.2` integra o SLS, os novos delimitadores e a camada de HTML/JS embutidos com paleta suave; evidências de testes reais e inspeção visual ficam no relatório desse candidato.
5. Migração: relatório das atribuições nulas e transformação léxica de colares; revisão manual das exclusões, tabelas posicionais, metatabelas, bancos, caches e bibliotecas C.
6. Distribuição: candidato local reversível, sem instalar serviços, publicar catálogos, alterar portal ou criar etiqueta de versão.

Uma versão maior só poderá ser proposta depois da migração e regressão do ecossistema, testes Debian/Windows/WebAssembly, ABI C final, orçamento de memória/desempenho e testes dos dois editores com o SLS completo. Resultados executados ficam no relatório do candidato; pendências não são tratadas como aprovadas.

## Decisão complementar — 23/10/2026, dados.7

Listas permanecem sem metatabelas nesta versão, por decisão explícita do usuário.
Isso não impede objetos compostos: uma tabela com metatabela pode conter listas.
O contrato de persistência atômica está em `experimentos/dados-v7/PERSISTENCIA.md`;
as evidências e limites estão em `experimentos/dados-v7/RELATORIO.md`. Continua
sendo candidato isolado, sem autorização para mudar produção.
